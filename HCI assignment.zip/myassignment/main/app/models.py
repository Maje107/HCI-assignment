from django.db import models
from datetime import date
from django.contrib.auth.models import AbstractUser
class TimetableEntry(models.Model):
    subject = models.CharField(max_length=100)
    day = models.CharField(
        max_length=10,
        choices=[
            ('Monday', 'Monday'),
            ('Tuesday', 'Tuesday'),
            ('Wednesday', 'Wednesday'),
            ('Thursday', 'Thursday'),
            ('Friday', 'Friday'),
            ('Saturday', 'Saturday'),
            ('Sunday', 'Sunday'),
        ]
    )
    start_time = models.TimeField()
    end_time = models.TimeField()
    due_date = models.DateField()  


    def is_upcoming(self):
        return self.due_date >= date.today()

    def is_past(self):
        return self.due_date < date.today()

    def __str__(self):
        return f"{self.subject} on {self.day} ({self.start_time} - {self.end_time})"



class CustomUser(AbstractUser):
    email = models.EmailField(unique=True)

    groups = models.ManyToManyField(
        "auth.Group",
        related_name="customuser_set",  # Custom related name to avoid conflicts
        blank=True
    )
    user_permissions = models.ManyToManyField(
        "auth.Permission",
        related_name="customuser_permissions_set",  # Custom related name
        blank=True
    )

    def __str__(self):
        return self.username