from django.shortcuts import render, redirect
from .models import TimetableEntry
from datetime import datetime
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login
import calendar
from collections import Counter

# Create your views here.

def create_task(request):
    if request.method == "POST":
        subject = request.POST.get("subject")
        day = request.POST.get("day")
        start_time = request.POST.get("start_time")
        end_time = request.POST.get("end_time")
        due_date = request.POST.get("due_date")  # Capture user input

        # Convert times & date to correct format
        start_time = datetime.strptime(start_time, "%H:%M").time()
        end_time = datetime.strptime(end_time, "%H:%M").time()
        due_date = datetime.strptime(due_date, "%Y-%m-%d").date()

        # Save to database
        TimetableEntry.objects.create(
            subject=subject,
            day=day,
            start_time=start_time,
            end_time=end_time,
            due_date=due_date
        )
        
        return redirect("timetable_notifications")  # Redirect to notification page

    return render(request, "create_timetable.html")

def timetable_list(request):
    entries = TimetableEntry.objects.all()
    return render(request, 'myhtmls/timetable_list.html', {'entries': entries})



def home_page(request):
    now = datetime.now().time()
    upcoming_entries = TimetableEntry.objects.filter(start_time__gte=now).order_by('day', 'start_time')[:10]
    
    # Count number of upcoming entries per subject
    subject_counter = Counter(entry.subject for entry in upcoming_entries)

    subject_data = {
        'labels': list(subject_counter.keys()),
        'hours': list(subject_counter.values()),  # this could represent "tasks" or "hours"
        'progress': [min(v * 10, 100) for v in subject_counter.values()],  # fake progress based on count
    }

    return render(request, 'myhtmls/home.html', {
        'entries': upcoming_entries,
        'subject_data': subject_data
        
    })



def timetable_notifications(request):
    entries = TimetableEntry.objects.all().order_by('due_date')
    
    for entry in entries:
        entry.upcoming = entry.is_upcoming()
        entry.past = entry.is_past()
    
    return render(request, 'timetable_notifications.html', {'entries': entries})

def landing_page(request):
    return render(request, 'landing_page.html')



def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]
        password = request.POST["password"]
        confirm_password = request.POST["confirm_password"]

        if password != confirm_password:
            messages.error(request, "Passwords do not match!")
            return redirect("register")

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists!")
            return redirect("register")

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email is already registered!")
            return redirect("register")

        user = User.objects.create_user(username=username, email=email, password=password)
        user.save()

        messages.success(request, "Registration successful! You can now log in.")
        return redirect("login")

    return render(request, "register.html")



def user_login(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect("home")  # Redirect to the home page after login
        else:
            return render(request, "login.html", {"error": "Invalid username or password"})

    return render(request, "login.html")


def calendar_view(request):
    today = datetime.today()
    current_year = today.year
    current_month = today.month

    # Generate a text-based calendar (Replace this with a more styled version in HTML)
    cal = calendar.monthcalendar(current_year, current_month)

    return render(request, 'myhtmls/calendar_template.html', {
        'year': current_year,
        'month': today.strftime('%B'),  # Get month name (e.g., "April")
        'calendar': cal,
    })