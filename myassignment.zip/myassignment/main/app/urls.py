from django.urls import path
from . import views 

urlpatterns = [
    path('home/', views.home_page, name="home"),
]


urlpatterns = [
    path('create_timetable/',views.create_task, name='create_timetable'),
    path('timetable/', views.timetable_list, name='timetable_list'),
     path('notifications/',views.timetable_notifications, name='timetable_notifications'),
     path('home/', views.home_page, name="home"),
    path("register/", views.register, name="register"),
     path("login/", views.user_login, name="login"),
     path("landing/",views.landing_page,name="landing_page"),
]

