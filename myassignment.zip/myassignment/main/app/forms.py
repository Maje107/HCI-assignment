from django import forms
from .models import Student

class StudentNumberForm(forms.Form):
    student_number = forms.CharField(label="Enter your student number", max_length=20)

class FundingStatusForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['funding_status']
